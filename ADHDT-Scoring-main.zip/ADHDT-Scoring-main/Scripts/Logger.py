
def log_error_function(func):
    def wrapper():
        try:
            return func()
        except Exception as e:
            print(f"Error has occured with function{func.__name__}! Check Error File for details!")
            with open("Log/log.txt", "a") as myfile:
                myfile.write(str(e)+"\n")
            return func()
    return wrapper
