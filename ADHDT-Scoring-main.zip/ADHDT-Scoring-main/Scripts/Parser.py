import json
import pandas as pd
from Logger import log_error_function

class ADHDT2Parser:

    def __init__(self, filepath:str, raw_data:str) -> None:
        with open(raw_data) as f:
            self.data = json.load(f)
        self.metaData = {}
        self.processed_data = {}
        self.__processing()
        with open(f"{filepath}/ADHDT2Answers.json", "w") as final:
            json.dump(self.processed_data, final)
        pass
    
    def get_sum_totals(self):
        typesDict = {"inattention":0,"hyperactivity":0}
        for i,key in enumerate(self.processed_data.keys()):
            if i < 14:
                typesDict["inattention"] +=self.processed_data[key]
            else:
                typesDict["hyperactivity"] +=self.processed_data[key]
        return typesDict

    def __processing(self):
        for key in self.data[0].keys():
            if "Question" in key:
                self.processed_data[key] = self.data[0][key] - 1
            else:
                self.metaData[key] = self.data[0][key]

class GARSParser:

    def __init__(self,filepath:str, raw_data:str) -> None:
        with open(raw_data) as f:
            self.data = json.load(f)
        self.metaData = {}
        self.processed_data = {}
        self.__processing()

        with open(f"{filepath}/GARS3Answers.json", "w") as final:
            json.dump(self.processed_data, final)
        pass

    def is_indiviudual_mute(self) -> bool:
        if self.metaData["Is the individual mute?"] == 2:
            return False
        else:
            return True

    def get_sum_total(self):
        typesDict = {"rrb":0,"si":0,"sc":0,"er":0,"cs":0,"ms":0}
        for i,key in enumerate(self.processed_data.keys()):
            if i < 13:
                typesDict["rrb"] +=self.processed_data[key]
            elif i < 27:
                typesDict["si"] +=self.processed_data[key]
            elif i < 36:
                typesDict["sc"] +=self.processed_data[key]
            elif i < 44:
                typesDict["er"] +=self.processed_data[key]
            elif i < 51:
                typesDict["cs"] +=self.processed_data[key]
            else:
                typesDict["ms"] +=self.processed_data[key]
        return typesDict


    def __processing(self):
        print(self.data)
        for key in self.data[0].keys():
            if "Question" in key:
                self.processed_data[key] = self.data[0][key] - 1
            else:
                self.metaData[key] = self.data[0][key]

class ADHDTTablesParser:

    def __init__(self,filename:str) -> None:
        self.scaleScoredf = pd.read_excel(filename, sheet_name="Scale Scores")
        self.indexScore = pd.read_excel(filename, sheet_name="ADHT Index Score",converters={'Gender':str,'Sum Score Inattention and Hyperactivity':int, 'Percentile Rank':str,'ADHD Index':int,'Interpretation':str})

    def __init__(self,filename1:str,filename2:str) -> None:
        self.scaleScoredf = pd.read_json(filename1,orient="records")
        self.indexScore = pd.read_json(filename2,orient="records") 
    
    def get_scaled_scores(self,gender:str,ageGroup:str,type:str,score:int,debug=False) -> int:
        df = self.scaleScoredf[(self.scaleScoredf["Gender"] ==gender) & (self.scaleScoredf["Age Group"]==ageGroup) & (self.scaleScoredf["Type"]==type)
                               & (self.scaleScoredf["Bottom Range"]<=score) & (self.scaleScoredf["Top Range"]>=score)]
        if debug:
            print(df)
        return df["Scaled Score"].iloc[0]

    def get_index_scores(self, gender:str, totalScore:int) -> pd.DataFrame:
        df = self.indexScore[(self.indexScore["Gender"]==gender) & (self.indexScore["Sum Score Inattention and Hyperactivity"]==totalScore)]
        return df

    def get_range_interpretation(self, interpretationType:str):
        df = self.indexScore[(self.indexScore["Interpretation"]==interpretationType)]
        print(df)
        print(df.max(axis=0)['ADHD Index']) # column AAL's max
        return df.min(axis=0)['ADHD Index'],df.max(axis=0)['ADHD Index']
    
    def get_percent_type(self ,gender:str,ageGroup:str,type:str,score:int):
        df = self.scaleScoredf[(self.scaleScoredf["Gender"]==gender) & (self.scaleScoredf["Age Group"]==ageGroup) & (self.scaleScoredf["Type"]==type)
                               & (self.scaleScoredf["Bottom Range"]<=score) & (self.scaleScoredf["Top Range"]>=score)]
        return str(df["Percentile Rank"].iloc[0])
    

class GARSTablesParser:

    def __init__(self,filename:str) -> None:
        self.scaleScoredf = pd.read_excel(filename, sheet_name="Raw Score Conversion")
        self.indexScore = pd.read_excel(filename, sheet_name="Scale To Percentile")

    def __init__(self,filename1:str,filename2:str) -> None:
        self.scaleScoredf = pd.read_json(filename1,orient="records")
        self.indexScore = pd.read_json(filename2,orient="records")

    def get_scaled_scores(self,type:str,score:int,debug=False) -> int:
        df = self.scaleScoredf[ (self.scaleScoredf["Type"]==type)
                            & (self.scaleScoredf["Raw Score Lower"]<=score) & (self.scaleScoredf["Raw Score Upper"]>=score)]
        if debug:
            print(df)
        return df["Scaled Score"].iloc[0]
    
    def get_percentage_score(self,type:str,score:int,debug=False) -> int:
        df = self.scaleScoredf[ (self.scaleScoredf["Type"]==type)
                            & (self.scaleScoredf["Raw Score Lower"]<=score) & (self.scaleScoredf["Raw Score Upper"]>=score)]
        if debug:
            print(df)
        return df["Percentile Rank"].iloc[0]
    
    def get_autism_index(self,type:str,score:int,debug=False) -> int:
        if score <12:
            df = self.indexScore[ (self.indexScore["Type"]==type)
                            & (self.indexScore["Scale Score"]=='<12')]
            
        else:
            df = self.indexScore[ (self.indexScore["Type"]==type)
                            & (self.indexScore["Scale Score"]==score)]
            
        if debug:
            print(df)
        return df["Autism Index"].iloc[0]
    
    def get_percentage_total_score(self,type:str,score:int,debug=False) -> int:
        if score <12:
            df = self.indexScore[ (self.indexScore["Type"]==type)
                            & (self.indexScore["Scale Score"]=="<12")]
        else:
            df = self.indexScore[ (self.indexScore["Type"]==type)
                            & (self.indexScore["Scale Score"]==score)]
        if debug:
            print(df)
        return df["Percentile Rank"].iloc[0]

    def get_asd_probs(self,asdscores:int):
        if asdscores <= 54:
            return "Unlikely", 0
        elif asdscores <=70:
            return "Probable", 1
        elif asdscores <=100:
            return "Likely", 2
        else:
            return "Very Likely", 3
        pass
    
