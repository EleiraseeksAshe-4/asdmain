import json

import Parser
import Processor
import time
import datetime
import os
import Results

def get_jsondata(filepath):
    with open(filepath, 'r') as f:
        data = json.load(f)
        return data

def main():

    if not os.path.isdir("Log"):
        os.mkdir("Log")
    
    with open("Log/log.txt", "w") as file:
        file.write(f"Running code Date: {str(datetime.datetime.today())}, Time: {str(datetime.datetime.now().time())}\n")

    tests = [['adhdt', 'adhdt2'], ['gars', 'gars3']]
    clientrefs = {'EliBak', 'JosHar'}

    fileroot = '/Users/johnbridges/Dropbox/NewHope Psychology/JoyConsulting/GateInc/ExpertReports/'

    for clientId in clientrefs:
        for test in tests:
            context = get_jsondata(f"{fileroot}/clients/active/{clientId}/word/{clientId}_context.json")
            Results.ResultForm(test, fileroot, clientId, context)

    # outputFile = "adhdt2Data.json"

    # jsonParser = Parser.ADHDT2Parser(os.path.join(inputDir,jfile))

    # adhdtIndexParser = Parser.ADHDTTablesParser(os.path.join(inputDir,adhdtIndexFile))

    # jsonProceessor = Processor.JsonProcessor(outputDir,outputFile)

    # print(jsonParser.processed_data)

    

    # totalScoresDict = jsonParser.get_sum_totals()

    # totalScore = 0

    # for key in totalScoresDict.keys():

    #     totalScore +=  (int)(adhdtIndexParser.get_scaled_scores(jsonParser.metaData["gender"], jsonParser.metaData["age_group"], key[0].upper() + key[1:],totalScoresDict[key]))
 
    
    # resultDf = adhdtIndexParser.get_index_scores(jsonParser.metaData["gender"], totalScore)

    # resultData = {'index_score': resultDf['ADHD Index'].iloc[0],
    #               'index_percent' : resultDf['Percentile Rank'].iloc[0],
    #               'rating' : resultDf['Interpretation'].iloc[0],
    #               'inattention_score': adhdtIndexParser.get_scaled_scores(jsonParser.metaData["gender"], jsonParser.metaData["age_group"], 'Inattention',totalScoresDict['inattention']),
    #               'inattention_percent': adhdtIndexParser.get_percent_type(jsonParser.metaData["gender"], jsonParser.metaData["age_group"], 'Inattention',totalScoresDict['inattention']),
    #               'hyper_score' : adhdtIndexParser.get_scaled_scores(jsonParser.metaData["gender"], jsonParser.metaData["age_group"], 'Hyperactivity',totalScoresDict['hyperactivity']),
    #               'hyper_percent' : adhdtIndexParser.get_percent_type(jsonParser.metaData["gender"], jsonParser.metaData["age_group"], 'Hyperactivity',totalScoresDict['hyperactivity'])
    #               }

    # print(resultData)
    # jsonProceessor.create_file(resultData)
    
if __name__ == "__main__":
    main()