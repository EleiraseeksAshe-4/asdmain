import openpyxl
from openpyxl.styles import Color, PatternFill, Font, Border
import json
import numpy as np
import os

class CSVProcessor:

    def __init__(self,outputfile:str) -> None:
        self.outputfile = outputfile

    def create_file(self,data:list,header:list):
        pass

class ExcelProcessor:

    def __init__(self,dir:str, outputfile:str) -> None:
        self.dir = dir
        self.outputfile = outputfile

    def create_file(self,adhtIndexScore:int,interpretationValue:str):
        wb = openpyxl.Workbook() 
  
        sheet = wb.active

        colourFill = PatternFill(start_color='A6C9EC',
                   end_color='A6C9EC',
                   fill_type='solid')
        
        colourFill = openpyxl.styles.colors.Color(rgb='A6C9EC')
        my_fill = openpyxl.styles.fills.PatternFill(patternType='solid', fgColor=colourFill)

        a1 = sheet.cell(row=1, column=1) 
  
        # writing values to cells 
        a1.value = "ADHT-2 Index"

        a1.fill = my_fill
        a1.font = Font(bold=True)

        b1 = sheet.cell(row=1, column=2) 

        b1.value = adhtIndexScore

        b1.font = Font(bold=True)

        b1.fill = my_fill
        
        a2 = sheet.cell(row=2, column=1) 
        a2.value = "Interpretation"

        a2.font = Font(bold=True)

        for i in range(3,8):
            tempCellValue = sheet.cell(row=i, column=1) 
            tempCellInterpretation = sheet.cell(row=i, column=2) 
            
            match i:
                case 3:
                    tempCellValue.value = "<= 54"
                    tempCellInterpretation.value = "Very Unlikely"
                    if interpretationValue == "Very Unlikely":
                        tempCellValue.fill  = my_fill
                        tempCellInterpretation.fill  = my_fill
                        tempCellInterpretation.font = Font(bold=True)
                        tempCellValue.font = Font(bold=True)
                case 4:
                    tempCellValue.value = "55-70"
                    tempCellInterpretation.value = "Unlikely"
                    if interpretationValue == "Unlikely":
                        tempCellValue.fill = my_fill
                        tempCellInterpretation.fill = my_fill
                        tempCellInterpretation.font = Font(bold=True)
                        tempCellValue.font = Font(bold=True)
                case 5:
                    tempCellValue.value = "71-79"
                    tempCellInterpretation.value = "Possible"
                    if interpretationValue == "Possible":
                        tempCellValue.fill = my_fill
                        tempCellInterpretation.fill = my_fill
                        tempCellInterpretation.font = Font(bold=True)
                        tempCellValue.font = Font(bold=True)
                case 6:
                    tempCellValue.value = "80-89"
                    tempCellInterpretation.value = "Likely"
                    if interpretationValue == "Likely":
                        tempCellValue.fill = my_fill
                        tempCellInterpretation.fill = my_fill
                        tempCellInterpretation.font = Font(bold=True)
                        tempCellValue.font = Font(bold=True)
                case 7:
                    tempCellValue.value = ">= 90"
                    tempCellInterpretation.value = "Very Likely"
                    if interpretationValue == "Very Likely":
                        tempCellValue.fill  = my_fill
                        tempCellInterpretation.fill = my_fill
                        tempCellInterpretation.font = Font(bold=True)
                        tempCellValue.font = Font(bold=True)
                case _:
                    raise Exception

        wb.save(os.path.join(self.dir,self.outputfile)) 


class JsonProcessor:

    def __init__(self,dir:str, outputfile:str) -> None:
        self.dir = dir
        self.outputfile = outputfile

    def create_file(self,adhd2_data:dict):
        json_object = json.dumps(adhd2_data,cls=NpEncoder)
 
        # Writing to sample.json
        with open(os.path.join(self.dir,self.outputfile), "w") as outfile:
            outfile.write(json_object)

### Converting data for json storage
class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super(NpEncoder, self).default(obj)