import pandas as pd
import json

def convert_xlsx_to_json(filename:str,typeName:str):
    xl = pd.ExcelFile(filename)

    for sheet_name in xl.sheet_names:
        results = []
        df = xl.parse(sheet_name)
        columnHeadings = list(df.columns.values)
        for i,row in df.iterrows():
            temp = {}
            for j,heading in enumerate(columnHeadings):
                temp[heading] = row[j]
            results.append(temp)
        
        with open(f"Input Files/{typeName}_{sheet_name}.json", "w") as final:
            json.dump(results, final)

convert_xlsx_to_json("Input Files/ADHDTTables.xlsx","ADHDT")
