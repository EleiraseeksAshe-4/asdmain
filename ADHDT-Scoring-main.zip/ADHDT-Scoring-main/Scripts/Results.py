import os
import Parser
import Processor
import time
from datetime import datetime

class ResultForm:

    def __init__(self, test, fileroot: str, clientId: str, context) -> None:
        self.inputDir = f"{fileroot}/clients/active/{clientId}/{test[0]}"
        self.outputDir = f"{fileroot}/clients/active/{clientId}/word"
        self.outputFile = f"{clientId}_adhdt2.json"
        self.fileroot = fileroot
        self.context = context

        self.jfile = f"{self.inputDir}/{clientId}_{test[1]}.json"

        if "adhdt" in test:
            self.adhdt_results()
        elif "gars" in test:
            self.gar_results()
        else:
            pass

    def gar_results(self):
        garRawScoreConvFile = f"{self.fileroot}/staticdata/GARS3_Raw Score Conversion.json"
        garScaleToPer = f"{self.fileroot}/staticdata/GARS3_Scale To Percentile.json"

        jsonParser = Parser.GARSParser(self.inputDir,self.jfile)

        garsIndexParser = Parser.GARSTablesParser(os.path.join(self.inputDir,garRawScoreConvFile),os.path.join(self.inputDir,garScaleToPer))

        jsonProcessor = Processor.JsonProcessor(self.outputDir,self.outputFile)

        totalScoresDict = jsonParser.get_sum_total()

        if jsonParser.is_indiviudual_mute():
            numberOfSubScale = "Sum of 4 subscales"
        else:
            numberOfSubScale = "Sum of 6 subscales"
        
        behaviouralScore = garsIndexParser.get_scaled_scores("Restricted/Repetitive Behaviors",totalScoresDict["rrb"])
        behaviouralPercentile = garsIndexParser.get_percentage_score("Restricted/Repetitive Behaviors",totalScoresDict["rrb"])

        socialInteractionScore = garsIndexParser.get_scaled_scores("Social Interaction",totalScoresDict["si"])
        socialInteractionPercentile = garsIndexParser.get_percentage_score("Social Interaction",totalScoresDict["si"])

        socialCommsScore = garsIndexParser.get_scaled_scores("Social Communication",totalScoresDict["sc"])
        socialCommsPercentile = garsIndexParser.get_percentage_score("Social Communication",totalScoresDict["sc"])

        emotionalRespScore = garsIndexParser.get_scaled_scores("Emotional Responses",totalScoresDict["er"])
        emotionalRespPercentile = garsIndexParser.get_percentage_score("Emotional Responses",totalScoresDict["er"])

        cognitiveStyleScore = garsIndexParser.get_scaled_scores("Cognitive Style",totalScoresDict["cs"])
        cognitiveStylePercentile = garsIndexParser.get_percentage_score("Cognitive Style",totalScoresDict["cs"])

        maladaptiveSpeechScore = garsIndexParser.get_scaled_scores("Maladaptive Speech",totalScoresDict["ms"])
        maladaptiveSpeechPercentile = garsIndexParser.get_percentage_score("Maladaptive Speech",totalScoresDict["ms"])

        if jsonParser.is_indiviudual_mute():
            totalScaleScore = behaviouralScore + socialInteractionScore + socialCommsScore + emotionalRespScore
        else:
            
            totalScaleScore = behaviouralScore + socialInteractionScore + socialCommsScore + emotionalRespScore + cognitiveStyleScore + maladaptiveSpeechScore

        totalScaleScore = behaviouralScore + socialInteractionScore + socialCommsScore + emotionalRespScore

        autism_index = garsIndexParser.get_autism_index("Sum of 4 subscales",totalScaleScore)

        total_score_percentage = garsIndexParser.get_percentage_total_score("Sum of 4 subscales",totalScaleScore)

        composite_rating, level = garsIndexParser.get_asd_probs(autism_index)
        resultData = {}
        resultData["GARS3_4"] = {
            'level' : level,
            'composite_score' : autism_index,
            'composite_percent' : total_score_percentage,
            'composite_rating' : composite_rating,
            'behaviour_percent': behaviouralPercentile,
            'behaviour_score': behaviouralScore,
            'sinter_percent': socialInteractionPercentile,
            'sinter_score': socialInteractionScore,
            'scomms_percent': socialCommsPercentile,
            'scomms_score': socialCommsScore,
            'emot_percent': emotionalRespPercentile,
            'emot_score': emotionalRespScore,
            'cog_percent': cognitiveStylePercentile,
            'cog_score': cognitiveStyleScore,
            'mal_percent': maladaptiveSpeechPercentile,
            'mal_score': maladaptiveSpeechScore
        }

        totalScaleScore = behaviouralScore + socialInteractionScore + socialCommsScore + emotionalRespScore + cognitiveStyleScore + maladaptiveSpeechScore

        autism_index = garsIndexParser.get_autism_index("Sum of 6 subscales",totalScaleScore)

        total_score_percentage = garsIndexParser.get_percentage_total_score("Sum of 6 subscales",totalScaleScore)

        composite_rating, level = garsIndexParser.get_asd_probs(autism_index)

        resultData["GARS3_6"] = {
            'level' : level,
            'composite_score' : autism_index,
            'composite_percent' : total_score_percentage,
            'composite_rating' : composite_rating,
            'behaviour_percent': behaviouralPercentile,
            'behaviour_score': behaviouralScore,
            'sinter_percent': socialInteractionPercentile,
            'sinter_score': socialInteractionScore,
            'scomms_percent': socialCommsPercentile,
            'scomms_score': socialCommsScore,
            'emot_percent': emotionalRespPercentile,
            'emot_score': emotionalRespScore,
            'cog_percent': cognitiveStylePercentile,
            'cog_score': cognitiveStyleScore,
            'mal_percent': maladaptiveSpeechPercentile,
            'mal_score': maladaptiveSpeechScore
        }

        print(resultData)
        jsonProcessor.create_file(resultData)

    def get_age_range(self, dob):
        # Calculate the age
        today = datetime.today()
        dob = datetime.strptime(dob, '%Y-%m-%d')
        age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))

        # Determine the age range
        if 5 <= age <= 7:
            return "Ages 5-7"
        elif 8 <= age <= 17:
            return "Ages 8-17"
        else:
            return "Age not in specified ranges"

    def adhdt_results(self):
        adhdtScaleScoreFile = f"{self.fileroot}/staticdata/ADHDT_Scale Scores.json"
        adhdtIndexScoreFile = f"{self.fileroot}/staticdata/ADHDT_ADHT Index Score.json"


        jsonParser = Parser.ADHDT2Parser(self.inputDir,self.jfile)

        adhdtIndexParser = Parser.ADHDTTablesParser(os.path.join(self.inputDir,adhdtScaleScoreFile),os.path.join(self.inputDir,adhdtIndexScoreFile))

        jsonProcessor = Processor.JsonProcessor(self.outputDir,self.outputFile)

        totalScoresDict = jsonParser.get_sum_totals()

        totalScore = 0

        for key in totalScoresDict.keys():
            gender = self.context['gender'].lower()
            dob = self.context['clientdob']
            age_range = self.get_age_range(dob)
            totalScore +=  (int)(adhdtIndexParser.get_scaled_scores(gender, age_range, key[0].upper() + key[1:],totalScoresDict[key]))
    
        
        resultDf = adhdtIndexParser.get_index_scores(gender, totalScore)

        resultData = {'index_score': resultDf['ADHD Index'].iloc[0],
                    'index_percent' : resultDf['Percentile Rank'].iloc[0],
                    'rating' : resultDf['Interpretation'].iloc[0],
                    'inattention_score': adhdtIndexParser.get_scaled_scores(gender, age_range, 'Inattention',totalScoresDict['inattention']),
                    'inattention_percent': adhdtIndexParser.get_percent_type(gender, age_range, 'Inattention',totalScoresDict['inattention']),
                    'hyper_score' : adhdtIndexParser.get_scaled_scores(gender, age_range, 'Hyperactivity',totalScoresDict['hyperactivity']),
                    'hyper_percent' : adhdtIndexParser.get_percent_type(gender, age_range, 'Hyperactivity',totalScoresDict['hyperactivity'])
                    }

        print(resultData)
        jsonProcessor.create_file(resultData)
    